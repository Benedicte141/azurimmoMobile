package bts.sio.azurimmo.model

data class Entreprise(
    val id: Int,
    val nom: String
)
